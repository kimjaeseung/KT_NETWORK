package com.kt.controller;
import static java.util.Base64.getEncoder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.tomcat.util.json.JSONParser;
import org.json.simple.JSONObject;

public class callAPI {
    protected String state = "all";
    //protected static String zone = "Seoul-M2";
    //protected static String zone = "Central-A";
    //private static String zoneid = "d7d0177e-6cda-404a-a46f-a5b356d2874e";

    private static String apikey = "jBkxdHVLCNBBV9jdyXKdR6OAeDq7b5sKy5SjK3rizZnSdrWxnul9GCN4OPCUODWNuSgsDQm2SoY2SSI06A-sfw";
    private static String secretKey = "RL4MwTUIcYpZY8UXnmzbYxjgye2Mwdnc6i37o_3QeTAFNptoTKPkgdsRqvOYqQJKmj2exAoKMPHXjp1Uuc3ahg";
    private static String baseurl="https://api.ucloudbiz.olleh.com/server/v2/client/api?";
    //private static String baseurl="https://api.ucloudbiz.olleh.com/server/v1/client/api?";
    /**
     * @param request command 생성에 필요한 값을 저장하는, 알파벳 순으로 정렬된 request
     * @return 생성된 signature
     * @brief 암호화 및 인코딩을 통한 signature 생성을 위한 함수
     **/

    String generateSig(TreeMap<String, String> request) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {

        List<String> list = new ArrayList<String>();

        Set<String> keys = request.keySet();

        for (String key : keys) {
            list.add(key.toLowerCase() + "=" + URLEncoder.encode(request.get(key), "UTF-8").replace("+", "%20").toLowerCase());
        }

        String sig_str = String.join("&", list);

        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA1");
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(keySpec);

        byte[] encryptedBytes = mac.doFinal(sig_str.getBytes());

        Base64.Encoder encoder = getEncoder();
        String signature = encoder.encodeToString(encryptedBytes);
        signature = URLEncoder.encode(signature, "UTF-8");


        return signature;
    }

    /**
     * @param request command 생성에 필요한 값을 저장하는, 알파벳 순 정렬 이전의 map
     * @return 생성된  최종 request url
     * @brief 생성된 signature를 사용하여 최종 request url 작성을 위한 함수
     **/
    private String generateReq(TreeMap<String, String> request) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
        //1. Quote_plus = replace ' ' with '+'
        //2. Making signature
        //3. final request query

        Set<String> keys = request.keySet();
        List<String> list = new ArrayList<String>();

        for (String key : keys) {
            list.add(key + "=" + request.get(key));
        }

        String request_str = String.join("&", list);

        String signature = generateSig(request);
        request_str = request_str + "&signature=" + signature;
        String req = baseurl + request_str;
        System.out.println(req);
        return req;
    }

    /**
     * @param req_message 데이터를 받아올 URL
     * @return 지정된 api 호출에 필요한 값을 저장하는 최종 request
     * @throws ParseException
     * @throws IOException
     * @brief URL로부터 JSON 데이터를 받아오는 함수
     **/    
    public static JSONObject readJsonFromUrl(String req_message) throws ParseException, IOException, org.json.simple.parser.ParseException {
        URL url = new URL(req_message);

        JSONParser parser = new JSONParser();
        JSONObject obj = null;

        // HTTPcache사용을 위해 HttpURLConnection 생성
        HttpURLConnection myURLConnection = (HttpURLConnection) url.openConnection();
        myURLConnection.setUseCaches(false);

        BufferedReader bf;
        String line = "";
        String result = "";
        int responseCode = myURLConnection.getResponseCode();
        if (responseCode == 200 ) {
            InputStream stream = myURLConnection.getErrorStream();
            if (stream == null) {
                bf = new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));
                while ((line = bf.readLine()) != null) {
                    result = result.concat(line);
                }
                //Log.i("INFO", result);
                obj = (JSONObject) parser.parse(result);
            }
            /************** For getting response from HTTP URL end ***************/
        } else {
            readJsonFromUrl(req_message);
        }
        return obj;
    }


    /**
     * @return
     * @throws ParseException
     * @brief Server 기능에 해당하는, 생성된 VM 정보 출력을 위한 함수
     * @return 각 서버의 서버명, 스펙, 상태, 생성일시, 운영체제를 가지고 있는 list
     */

    public ArrayList<String[]> listPortforwardingRule(String zone_name) throws IOException, InvalidKeyException, NoSuchAlgorithmException, ParseException, NullPointerException {

        TreeMap<String, String> request = new TreeMap<String, String>();

        request.put("command", "listPortForwardingRules" );
        if (zone_name.equals("Seoul-M2")) {
            request.put("zoneid","d7d0177e-6cda-404a-a46f-a5b356d2874e");
            baseurl="https://api.ucloudbiz.olleh.com/server/v2/client/api?";
        }else if(zone_name.equals("Central/Seoul-M")){
            request.put("zoneid","95e2f517-d64a-4866-8585-5177c256f7c7");
            baseurl="https://api.ucloudbiz.olleh.com/server/v1/client/api?";}
//        }else if(zone_name.equals("Central-A")){
//            request.put("zoneid","eceb5d65-6571-4696-875f-5a17949f3317");
//        }else if(zone_name.equals("Central-B")){
//            request.put("zoneid","9845bd17-d438-4bde-816d-1b12f37d5080");
//        }
        //request.put("zoneid", zoneid);
        //request.put("zoneid", "eceb5d65-6571-4696-875f-5a17949f3317");
        request.put("response", "json");
        request.put("apiKey", getApikey());

        String req_message;// = generateReq(request);
        JSONObject obj;//obj = readJsonFromUrl(req_message);
        JSONObject parse_listPortForwardingRulesresponse;
        JSONArray parse_listPortForwardingRules;
        JSONObject nic;

        JSONObject portforwarding;

        //String num = "22";
        ArrayList<String[]> list = new ArrayList<String[]>();
        String name, privateport, publicport, ip, state, privateip;

        try{
            // request 전처리
            req_message = generateReq(request);
            System.out.print(req_message);
            obj = readJsonFromUrl(req_message);
            while(obj==null){
                obj = readJsonFromUrl(req_message);
            }

            parse_listPortForwardingRulesresponse = (JSONObject) obj.get("listportforwardingrulesresponse");

            if(parse_listPortForwardingRulesresponse.isEmpty()){

            } else {
                parse_listPortForwardingRules = (JSONArray) parse_listPortForwardingRulesresponse.get("portforwardingrule");

                for (int i = 0; i < parse_listPortForwardingRules.size(); i++) {

                    portforwarding = (JSONObject) parse_listPortForwardingRules.get(i);
                    name = (String)portforwarding.get("virtualmachinedisplayname");
                    publicport = (String)portforwarding.get("publicport");
                    privateport = (String)portforwarding.get("privateport");
                    ip = (String)portforwarding.get("ipaddress");
                    state = (String)portforwarding.get("state");
                    privateip = (String)portforwarding.get("vmguestip");

                    if(privateport.equals("22")){
                        list.add(new String[]{name,publicport,privateport,ip,state,privateip});

                    }
                    else{
                        continue;
                    }
                }
            }
        } catch (NullPointerException e){
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
            e.printStackTrace();
        }


        return list;

    }

//    private String getZone() {
//
//        return zone;
//    }

    private String getApikey() {

        return apikey;
    }
}