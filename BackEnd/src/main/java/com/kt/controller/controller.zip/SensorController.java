package com.kt.controller;

import static java.util.Base64.getEncoder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api("Controller V1")
@RestController
@CrossOrigin(origins = "http://localhost:8081")
public class SensorController {
	static String $URL = "https://api.ucloudbiz.olleh.com/server/v2/client/api?";
	static String $APIKEY = "bjatL1TklBIHV9DYCb_W42jTv4sEW8qAOLbjy1GW4ulIrWJ0zsudzkH478pMpn2OSrWIdXrbDnrwV-JdRBtVUQ";
	static String $SECRETKEY = "bIP_4fV2snLb1zlUIori5-xtuVZ5tbEDxh1YFFPqCZb1_YrbK-OBdzy3Ouq8o1RvdPPAFDBkVOV7dNALK7HRpA";
	static String $COMMAND = "listVirtualMachines&response=json";
	
	@ApiOperation(value = "KT Cloud Port forwarding 조회", notes = "조회", response = Map.class)
	@GetMapping(value = "/ktportforwarding")
	public JSONObject ktportforwarding() throws ParseException, IOException, org.json.simple.parser.ParseException, org.apache.tomcat.util.json.ParseException {
		JSONObject real = resulturl("listPortForwardingRules&response=json");		
		return real;
	}
	
	@ApiOperation(value = "KT Cloud Server 조회", notes = "조회", response = Map.class)
	@GetMapping(value = "/ktserver")
	public JSONObject ktserver() throws NoSuchAlgorithmException, InvalidKeyException, IOException, ParseException,
			org.json.simple.parser.ParseException, org.apache.tomcat.util.json.ParseException {
		JSONObject real = resulturl("listVirtualMachines&response=json");
		return real;
	}
	@ApiOperation(value = "KT Cloud Firewall 조회", notes = "조회", response = Map.class)
	@GetMapping(value = "/ktfirewall")
	public JSONObject ktfirewall() throws NoSuchAlgorithmException, InvalidKeyException, IOException, ParseException,
			org.json.simple.parser.ParseException, org.apache.tomcat.util.json.ParseException {
		JSONObject real = resulturl("listFirewallRules&response=json");
		System.out.println(real.keySet());	
		
		return real;
	}	
	@ApiOperation(value = "test data list", notes = "성공/실패 여부에 따라 http 상태코드 출력", response = Map.class)
	@GetMapping(value = "/test")
	public ResponseEntity<List<Map<String, String>>> test() {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		HttpStatus status = null;
		Map<String, String> map = new HashMap<String, String>();
		map.put("data", "kimjaeseung zz zz zz");
		list.add(map);
		status = HttpStatus.ACCEPTED;
		return new ResponseEntity<List<Map<String, String>>>(list, status);
	}
	
	
	public static String createSignature(String data, String key) throws java.security.SignatureException
	{
		String result;
		try {
			SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(), "HmacSHA1");
			Mac mac = Mac.getInstance("HmacSHA1");
			mac.init(signingKey);
			byte[] rawHmac = mac.doFinal(data.getBytes());
			
			Base64.Encoder encoder = getEncoder();
	        String signature = encoder.encodeToString(rawHmac);			
			result = URLEncoder.encode(signature, "UTF-8");
		} 
		catch (Exception e) {
			throw new SignatureException("Failed to generate HMAC : " + e.getMessage());
		}
		return result;
	}	

	public static JSONObject readJsonFromUrl(String req_message) throws ParseException, IOException,
			org.json.simple.parser.ParseException, org.apache.tomcat.util.json.ParseException {
		URL url = new URL(req_message);
		JSONParser parser = new JSONParser();
		JSONObject obj = null;

		// HTTPcache사용을 위해 HttpURLConnection 생성
		HttpURLConnection myURLConnection = (HttpURLConnection) url.openConnection();
		myURLConnection.setUseCaches(false);

		BufferedReader bf;
		String line = "";
		String result = "";
		int responseCode = myURLConnection.getResponseCode();
		if (responseCode == 200) {
			InputStream stream = myURLConnection.getErrorStream();
			if (stream == null) {
				bf = new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));
				while ((line = bf.readLine()) != null) {
					result = result.concat(line);
				}
				// Log.i("INFO", result);
				obj = (JSONObject) parser.parse(result);
			}
			/************** For getting response from HTTP URL end ***************/
		} else {
			readJsonFromUrl(req_message);
		}
		System.out.println("받아온값: " +obj);
		return obj;
	}
	public JSONObject resulturl(String command) throws ParseException, IOException, org.json.simple.parser.ParseException, org.apache.tomcat.util.json.ParseException {
		String request = "command=" + command + "&apikey=" + $APIKEY;
		request = request.replace(" ", "%20");
		String[] s = request.split("&");
		Arrays.sort(s);
		request = s[0];
		for(int i=1;i<s.length;i++){
			request = request + "&" + s[i];
		}
		String request_e = "";
		request_e=request.toLowerCase();
		String signature = "";
		try {
			signature = createSignature(request_e, $SECRETKEY);
		} catch (SignatureException e) {
			e.printStackTrace();
		}
		String result = $URL + request + "&signature=" + signature;
		System.out.println(result);
		JSONObject real = readJsonFromUrl(result);
		return real;
	}
	
}
